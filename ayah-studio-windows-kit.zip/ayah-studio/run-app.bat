@echo off
set "F=%~dp0verse-batch-tool.html"
set "U=file:///%F:\=/%"
start "" msedge --app="%U%" 2>nul
if errorlevel 1 start "" chrome --app="%U%" 2>nul
if errorlevel 1 start "" "%F%"
