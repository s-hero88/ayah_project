@echo off
where node >nul 2>nul
if errorlevel 1 (
  echo Please install Node.js first: https://nodejs.org
  pause
  exit /b 1
)
call npm install
if errorlevel 1 (pause & exit /b 1)
call npm run dist
echo.
echo Done. Your exe is inside the "dist" folder.
pause
